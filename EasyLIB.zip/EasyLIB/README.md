Thank You For Downloading EasyLIB.

This is a mod that you can use for addons or just making games.

Documentation:

To access all the functions first import EasyLIB
Then type API.classname.functionname

1) Calculator:

Use the calculator class to calculate numbers.
The functions will have a modifier (+ - * /)
Then they will have the amount (1 - 4)
Then they will have the type (int, float, double, string)
Then pass in the values. The amount of values will depend on
the amount you chose (1 - 4).
Then it will return the value.

2) FileHandler:

Use The FileHandler to handler files.

The first function will be to make a file.

First Call The CreateFile function. Give it a path like C:\hello.txt

Then It will return a bool to say if it was sucsessfull or if it failed.

The Second function is to write to a already existing file.

First Call The WriteToFile function. Give it a path like C:\hello.txt

Then it will return a bool to say if it was sucsessfull or if it failed

The Third Function is to read a already existing file.

First Call The ReadFile function. Give it a path like C:\hello.txt

Then it will return null if it failed or the value if it was sucsessfull

The Last Function is to make a directory (folder)

First Call The Function CreateDirectory. Give it a path like C:\hello

Then it will return a bool to say if it  sucsessfull or if it failed.
