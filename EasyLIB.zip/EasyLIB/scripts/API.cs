﻿using UnityEngine;
using System.IO;


namespace EasyLIB
{

    public static class API
    {
        
        public static class Calculator
        {
            public static int add2Int(int n1, int n2)
            {
                return n1 + n2;
            }
            public static float add2Float(float n1, float n2)
            {
                return n1 + n2;
            }
            public static double add2Double(double n1, double n2)
            {
                return n1 + n2;
            }
            public static string add2String(string n1, string n2)
            {
                return n1 + n2;
            }

            public static int Subtract2Int(int n1, int n2)
            {
                return n1 - n2;
            }
            public static float Subtact2Float(float n1, float n2)
            {
                return n1 - n2;
            }
            public static double Subtract2Double(double n1, double n2)
            {
                return n1 - n2;
            }

            public static int Multiply2Int(int n1, int n2)
            {
                return n1 * n2;
            }
            public static float Multiply2Float(float n1, float n2)
            {
                return n1 * n2;
            }
            public static double Multiply2Double(double n1, double n2)
            {
                return n1 * n2;
            }
            public static int Divide2Int(int n1, int n2)
            {
                return n1 / n2;
            }
            public static float Divide2Float(float n1, float n2)
            {
                return n1 / n2;
            }
            public static double Divide2Double(double n1, double n2)
            {
                return n1 / n2;
            }
            // 3
            public static int add3Int(int n1, int n2, int n3)
            {
                return n1 + n2 + n3;
            }
            public static float add3Float(float n1, float n2, float n3)
            {
                return n1 + n2 + n3;
            }
            public static double add3Double(double n1, double n2, double n3)
            {
                return n1 + n2 + n3;
            }
            public static string add3String(string n1, string n2, string n3)
            {
                return n1 + n2 + n3;
            }

            public static int Subtract3Int(int n1, int n2, int n3)
            {
                return n1 - n2 - n3;
            }
            public static float Subtact3Float(float n1, float n2, int n3)
            {
                return n1 - n2 - n3;
            }
            public static double Subtract3Double(double n1, double n2, double n3)
            {
                return n1 - n2 - n3;
            }

            public static int Multiply3Int(int n1, int n2, int n3)
            {
                return n1 * n2 * n3;
            }
            public static float Multiply3Float(float n1, float n2, float n3)
            {
                return n1 * n2 * n3;
            }
            public static double Multiply3Double(double n1, double n2, double n3)
            {
                return n1 * n2 * n3;
            }
            public static int Divide3Int(int n1, int n2, int n3)
            {
                return n1 / n2 / n3;
            }
            public static float Divide3Float(float n1, float n2, float n3)
            {
                return n1 / n2 / n3;
            }
            public static double Divide3Double(double n1, double n2, double n3)
            {
                return n1 / n2 / n3;
            }
            // 4
            public static int add4Int(int n1, int n2, int n3, int n4)
            {
                return n1 + n2 + n3 + n4;
            }
            public static float add4Float(float n1, float n2, float n3, float n4)
            {
                return n1 + n2 + n3 + n4;
            }
            public static double add4Double(double n1, double n2, double n3, double n4)
            {
                return n1 + n2 + n3 + n4;
            }
            public static string add4String(string n1, string n2, string n3, double n4)
            {
                return n1 + n2 + n3 + n4;
            }

            public static int Subtract4Int(int n1, int n2, int n3, int n4)
            {
                return n1 - n2 - n3 - n4;
            }
            public static float Subtact4Float(float n1, float n2, float n3, float n4)
            {
                return n1 - n2 - n3 - n4;
            }
            public static double Subtract4Double(double n1, double n2, double n3, double n4)
            {
                return n1 - n2 - n3 - n4;
            }

            public static int Multiply4Int(int n1, int n2, int n3, int n4)
            {
                return n1 * n2 * n3 * n4;
            }
            public static float Multiply4Float(float n1, float n2, float n3, float n4)
            {
                return n1 * n2 * n3 * n4;
            }
            public static double Multiply4Double(double n1, double n2, double n3, double n4)
            {
                return n1 * n2 * n3 * n4;
            }
            public static int Divide4Int(int n1, int n2, int n3, int n4)
            {
                return n1 / n2 / n3 / n4;
            }
            public static float Divide4Float(float n1, float n2, float n3, float n4)
            {
                return n1 / n2 / n3 / n4;
            }
            public static double Divide4Double(double n1, double n2, double n3, double n4)
            {
                return n1 / n2 / n3 / n4;
            }
        }

        public static class FileHandler
        {
            public static bool CreateFile(string path)
            {
                if (File.Exists(path))
                {
                    return false;
                }

                FileStream s = File.Create(path);
                s.Close();
                return true;
            }
            public static bool WriteToFile(string path, string text)
            {
                if (!File.Exists(path))
                {
                    return false;
                }
                File.WriteAllText(path, text);
                return true;
            }
            public static string ReadFile(string path)
            {
                if (!File.Exists(path))
                {
                    return null;
                }

                return File.ReadAllText(path);

            }
            public static bool CreateDirectory(string path)
            {
                if (Directory.Exists(path))
                {
                    return false;
                }
                Directory.CreateDirectory(path);
                return true;
            }
        }
    }
}
